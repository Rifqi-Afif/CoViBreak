setInterval(nextPage, 3000);

function nextPage()
{
  window.location.href="https://covibreak-markoding01.markoding01.repl.co/beranda.html"
}